﻿<?php

 
defined('_JEXEC') or die('Restricted access');



?><?php
class plgHikashoppaymentsn extends hikashopPaymentPlugin
{
	var $accepted_currencies = array(
		'AUD','BRL','CAD','EUR','GBP','JPY','USD','NZD','CHF','HKD','SGD','SEK',
		'DKK','PLN','NOK','HUF','CZK','MXN','MYR','PHP','TWD','THB','ILS','TRY','IRR'
	);

	var $multiple = true;
	var $name = 'sn';
	var $doc_form = 'sn';

	function __construct(&$subject, $config) {
		parent::__construct($subject, $config);
		
	}

	function onBeforeOrderCreate(&$order,&$do){
	
		if(parent::onBeforeOrderCreate($order, $do) === true)
			return true;
	}

	function onAfterOrderConfirm(&$order, &$methods, $method_id) {
		parent::onAfterOrderConfirm($order, $methods, $method_id);
		
		if($this->currency->currency_locale['int_frac_digits'] > 2)
			$this->currency->currency_locale['int_frac_digits'] = 2;
			
		$pluginsClass = hikashop_get('class.plugins');
		$elements = $pluginsClass->getMethods('payment','sn');
		$element = reset($elements);
		
		$mainframe = jfactory::getapplication();
// Security
@session_start();
$sec = uniqid();
$md = md5($sec.'vm');
// Security


		$amount = (int)$order->order_full_price;
		$return = HIKASHOP_LIVE.'index.php?option=com_hikashop&ctrl=checkout&task=notify&notif_payment='.$element->payment_type.'&tmpl=component&lang='.$this->locale . $this->url_itemid."&orderid=".$order->order_id."&amount=".$amount.'&md='.$md.'&sec='.$sec;
		$api = $element->payment_params->merchant;
		$amount =  $amount / 10; //Tooman
		$callbackUrl = $return;
		$orderId = $order->order_id;

		 
		$data_string = json_encode(array(
'pin'=> $api,
'price'=> $amount,
'callback'=> $callbackUrl ,
'order_id'=> $orderId,
'ip'=> $_SERVER['REMOTE_ADDR'],
'callback_type'=>2
));

$ch = curl_init('https://developerapi.net/api/v1/request');
curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Content-Type: application/json',
'Content-Length: ' . strlen($data_string))
);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 20);
$result = curl_exec($ch);
curl_close($ch);


$json = json_decode($result,true);
if(!empty($json['result']) AND $json['result'] == 1)
{
						session_start();
						// Set Session
				$_SESSION[$sec] = [
					'price'=>$amount ,
					'order_id'=>$orderId ,
					'au'=>$json['au'] ,
				];
	 echo ('<div style="display:none">'.$json['form'].'</div>Please wait ... <script language="javascript">document.payment.submit(); </script>');
		
		}else{
		
			$url = HIKASHOP_LIVE."index.php?option=com_hikashop&ctrl=checkout";
			$mess .= 'خطا در اتصال به درگاه'."<br>";
			$mess .= $json['msg'];
			$app = jfactory::getapplication();
			$app->redirect($url,$mess);			
		
		}
	}

	function onPaymentNotification(&$statuses) {
		
		$pluginsClass = hikashop_get('class.plugins');
		$elements = $pluginsClass->getMethods('payment','sn');
		$element = reset($elements);	

		$order_id = jRequest::getVar('orderid');
		
		$dbOrder = $this->getOrder((int)$order_id);
		$this->loadPaymentParams($dbOrder);
		if(empty($this->payment_params))
			return false;
		$this->loadOrderData($dbOrder);

		if(!$this->payment_params->notification)
			return false;
		if($this->payment_params->debug)
			echo print_r($vars, true) . "\r\n\r\n";
		if(empty($dbOrder)) {
			echo 'Could not load any order for your notification ' . @$vars['invoice'];
			return false;
		}	
		
		$url = HIKASHOP_LIVE."index.php?option=com_hikashop&ctrl=order&task=show&cid=$order_id";
		$order_text = "\r\n" . JText::sprintf('NOTIFICATION_OF_ORDER_ON_WEBSITE', $dbOrder->order_number, HIKASHOP_LIVE);
		$order_text .= "\r\n" . str_replace('<br/>', "\r\n", JText::sprintf('ACCESS_ORDER_WITH_LINK', $url));
		$ip = hikashop_getIP();
		$ips = str_replace(array('.', '*', ','), array('\.', '[0-9]+', '|'), $this->payment_params->ips);
		
		
		
		$api = $element->payment_params->merchant;
session_start();
// Security
$sec=$_GET['sec'];
$mdback = md5($sec.'vm');
$mdurl=$_GET['md'];
// Security
//get data from session
$transData = $_SESSION[$sec];
$au=$transData['au']; //
$order_id=$transData['order_id']; //
$amount=$transData['price']; //
	if(isset($_GET['sec']) or isset($_GET['md']) AND $mdback == $mdurl ){
// CallBack
$bank_return = $_POST + $_GET ;
$data_string = json_encode(array (
'pin' => $api,
'price' => $amount,
'order_id' => $order_id,
'au' => $au,
'bank_return' =>$bank_return,
));

$ch = curl_init('https://developerapi.net/api/v1/verify');
curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Content-Type: application/json',
'Content-Length: ' . strlen($data_string))
);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 20);
$result = curl_exec($ch);
curl_close($ch);
$json = json_decode($result,true);	
		
		if( ! empty($json['result']) and $json['result'] == 1){
			$history = new stdClass();
			$email = new stdClass();
			$history->notified = 1;
			$history->order_invoice_number = $au;
			$history->data = '<div class="red">پرداخت با موفقیت انجام شد'.'<br>شناسه پرداخت:'.$au."</div>";
			$payment_status = 'Accepted';
			$email->body = str_replace('<br/>',"\r\n",JText::sprintf('PAYMENT_NOTIFICATION_STATUS','sn', $payment_status)).' '.JText::sprintf('ORDER_STATUS_CHANGED', $statuses[$order_status])."\r\n\r\n".$order_text;
			$email->subject = JText::sprintf('PAYMENT_NOTIFICATION_FOR_ORDER', 'sn', $payment_status, $dbOrder->order_number);	
			$cartClass = hikashop_get('class.cart');
			$cartClass->resetCart();
			$order_status = $this->payment_params->verified_status;
			$this->modifyOrder($order_id, $order_status, $history, $email);
		
			$app = jfactory::getapplication();
			$app->redirect($url,$history->data);			
		}
		else{
			
			$url = HIKASHOP_LIVE."index.php?option=com_hikashop&ctrl=checkout";
			$mess .= 'کاربر منصرف شده است'."<br>";
			$mess .= $json['msg'];
			$app = jfactory::getapplication();
			$app->redirect($url,$mess);					
			
		}		
			}
		else{
			
			$url = HIKASHOP_LIVE."index.php?option=com_hikashop&ctrl=checkout";
			$mess .= 'کاربر منصرف شده است'."<br>";
			$mess .= $json['msg'];
			$app = jfactory::getapplication();
			$app->redirect($url,$mess);					
			
		}		
		
	}
	
	
	function onPaymentConfiguration(&$element) {
		$subtask = JRequest::getCmd('subtask', '');
		if($subtask == 'ips') {
			$ips = null;
			echo implode(',', $this->_getIPList($ips));
			exit;
		}

		parent::onPaymentConfiguration($element);
		$this->address = hikashop_get('type.address');


	}

	function onPaymentConfigurationSave(&$element) {
		if(!empty($element->payment_params->ips))
			$element->payment_params->ips = explode(',', $element->payment_params->ips);
		return true;
	}

	function getPaymentDefaultValues(&$element) {
		$element->payment_name = 'sn';
		$element->payment_description='You can pay by credit card or sn using this payment method';
		$element->payment_images = 'MasterCard,VISA,Credit_card,sn';

		$element->payment_params->url = 'https://www.sn.me';
		$element->payment_params->notification = 1;
		$element->payment_params->ips = '';
		$element->payment_params->details = 0;
		$element->payment_params->invalid_status = 'cancelled';
		$element->payment_params->pending_status = 'created';
		$element->payment_params->verified_status = 'confirmed';
		$element->payment_params->address_override = 1;
	}

	function _getIPList(&$ipList) {
		$hosts = array(
			'www.sn.com',
			'notify.sn.com',
			'ipn.sandbox.sn.com'
		);

		$ipList = array();
		foreach($hosts as $host) {
			$ips = gethostbynamel($host);
			if(!empty($ips)) {
				if(empty($ipList))
					$ipList = $ips;
				else
					$ipList = array_merge($ipList, $ips);
			}
		}

		if(empty($ipList))
			return $ipList;

		$newList = array();
		foreach($ipList as $k => $ip) {
		$ipParts = explode('.', $ip);
		if(count($ipParts) == 4) {
			array_pop($ipParts);
			$ip = implode('.', $ipParts) . '.*';
		}
		if(!in_array($ip, $newList))
			$newList[] = $ip;
		}
		return $newList;
	}
}
