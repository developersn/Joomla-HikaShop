<?php
defined('_JEXEC') or die('Restricted access');

jimport('sncore.include');

class plgHikashoppaymentSn_hikashop extends hikashopPaymentPlugin
{
	var $accepted_currencies = array('IRR','IRT','TOM');
	var $multiple = true;
	var $name = 'sn_hikashop';
	var $doc_form = 'sn_hikashop';
    var $pluginConfig = array();

    public $defaultAcceptedCurrencies = array('IRR','IRT','TOM');
    public $defaultAcceptedCurrenciesLower = array('irr','irt','tom');

    function __construct(&$subject, $config)
	{
        SNGlobal::loadLanguage('plg_hikashoppayment_sn_hikashop',JPATH_ADMINISTRATOR);

		/* Set Publish Currency to select for connect to portal - admin config */
        $publishCurrency = SNGlobal::selectByQuery("SELECT `currency_symbol`,`currency_code` FROM `#__hikashop_currency` WHERE `currency_published`='1'");
        $publishCurrencyCodes = !empty($publishCurrency) ? array_column($publishCurrency,'currency_code') : array();
        $publishCurrencyCodes = array_unique(array_merge($this->defaultAcceptedCurrencies,$publishCurrencyCodes));
        $publishCurrencyCodes = array_combine($publishCurrencyCodes,$publishCurrencyCodes);
        $this->pluginConfig = array(
            'sn_pin' => array("پین درگاه (API)",'input'),
            'sn_currency' => array('واحد پول سایت','list',array(
                '1' => 'ریال',
                '0' => 'تومان',
            )),
            'sn_send_payer_info' => array('ارسال اطلاعات پرداخت کننده','list',array(
                '1' => 'فعال',
                '0' => 'غیرفعال',
            )),
            'available_currency' => array(
                'واحدهای پولی مجاز',
                'checkbox',
                $publishCurrencyCodes
            ),
        );

        /* Set Accepted Currencies */
        if(SNGlobal::isBackend() && SNGlobal::getVar('option') == 'com_hikashop' && SNGlobal::getVar('ctrl') == 'plugins')
        {
            $this->accepted_currencies = array_values($publishCurrencyCodes);
            SNGlobal::addScriptDeclaration('
                document.addEventListener(\'DOMContentLoaded\', function() {
                   document.querySelector("input[type=\'checkbox\'][name*=\'available_currency\'][value=\'IRT\']").checked = true;
                   document.querySelector("input[type=\'checkbox\'][name*=\'available_currency\'][value=\'IRR\']").checked = true;
                   document.querySelector("input[type=\'checkbox\'][name*=\'available_currency\'][value=\'TOM\']").checked = true;
                }, false);
            ');
        }
        else
        {
            $params = SNGlobal::selectByQuery("SELECT `payment_params` FROM `#__hikashop_payment` WHERE `payment_type`='sn_hikashop'",2);
            $params = !empty($params['payment_params']) ? unserialize($params['payment_params']) : array();
            $params = !empty($params->available_currency) ? $params->available_currency : array();
            $this->accepted_currencies = array_unique(array_merge($params,$this->defaultAcceptedCurrencies,$this->defaultAcceptedCurrenciesLower));
        }

        parent::__construct($subject, $config);
    }

	function onBeforeOrderCreate(&$order,&$do)
	{
        if(parent::onBeforeOrderCreate($order,$do) === true)
        {
            return true;
        }
		return true;
	}

	function onAfterOrderConfirm(&$order, &$methods, $method_id)
	{
		parent::onAfterOrderConfirm($order,$methods,$method_id);

        $app = JFactory::getApplication();

		$backUrl = HIKASHOP_LIVE.'index.php?option=com_hikashop&ctrl=checkout&task=notify&notif_payment='.$this->name.'&tmpl=component&lang='.$this->locale .'&order_id=' . $order->order_id;
        $cancelUrl = HIKASHOP_LIVE.'index.php?option=com_hikashop&ctrl=order&task=cancel_order&order_id='.$order->order_id;

        $amount = round($order->cart->full_total->prices[0]->price_value_with_tax,(int)$this->currency->currency_locale['int_frac_digits']);

		if($amount > 0)
		{
            $email = !empty($order->customer->user_email) ? $order->customer->user_email : '';
            $phone = !empty($order->cart->shipping_address->address_telephone) ? $order->cart->shipping_address->address_telephone : '';
            $orderId = !empty($order->order_id) ? $order->order_id : 0;

            $pin = $this->payment_params->sn_pin;
            $currency = $this->payment_params->sn_currency;
            $sendPayerInfo = $this->payment_params->sn_send_payer_info;

            $amount = SNApi::modifyPrice($amount,$currency);

            $data = array(
                'pin'=> $pin,
                'price'=> $amount,
                'callback'=> $backUrl,
                'order_id'=> $orderId,
                'email'=> $email,
                'description'=> '',
                'mobile'=> $phone,
            );

            list($status,$msg,$resultData) = SNApi::request($data,$sendPayerInfo,'hikashop');

            if($status == true)
            {
                $formDetails = $resultData['form_details'];

                $data['bank_callback_details'] = $resultData['bank_callback_details'];
                $data['au'] = $resultData['au'];

                SNApi::clearData();
                SNApi::setData($data);

                $this->vars = $formDetails;
                return $this->showPage('end');
            }
        }

        $msg = $msg;
        $app->redirect($cancelUrl, '<h5>'.$msg.'</h5>','error');
	}

	function onPaymentNotification(&$statuses)
	{
        $app = JFactory::getApplication();

        $orderId = SNGlobal::getVar('order_id','','none','request');
        $au = SNGlobal::getVar('au','','none','request');
        $sessionData = SNApi::getData();

        $successUrl = HIKASHOP_LIVE.'index.php?option=com_hikashop&ctrl=checkout&task=after_end&order_id='.$orderId;
        $cancelUrl = HIKASHOP_LIVE.'index.php?option=com_hikashop&ctrl=order&task=cancel_order&order_id='.$orderId;

        if(!empty($orderId) && !empty($au) && !empty($sessionData) && $sessionData['order_id'] == $orderId)
	    {
            $dbOrder = $this->getOrder($orderId);
            $this->loadPaymentParams($dbOrder);

            if(!empty($this->payment_params) && !empty($dbOrder))
            {
                $url = HIKASHOP_LIVE.'administrator/index.php?option=com_hikashop&ctrl=order&task=edit&order_id=' . $orderId;

                $orderText = "\r\n" . JText::sprintf('NOTIFICATION_OF_ORDER_ON_WEBSITE', $dbOrder->order_number, HIKASHOP_LIVE);
                $orderText .= "\r\n" . str_replace('<br/>', "\r\n", JText::sprintf('ACCESS_ORDER_WITH_LINK', $url));

                if($orderId)
                {
                    $bankData = array();
                    foreach (!empty($sessionData['bank_callback_details']['params']) ? $sessionData['bank_callback_details']['params'] : array() as $bankParam)
                    {
                        $bankData[$bankParam] = !empty($_REQUEST[$bankParam]) ? $_REQUEST[$bankParam] : '';
                    }

                    $data = array (
                        'pin' => $sessionData['pin'],
                        'price' => $sessionData['price'],
                        'order_id' => $sessionData['order_id'],
                        'au' => $au,
                        'bank_return' => $bankData,
                    );

                    list($status,$msg,$resultData) = SNApi::verify($data,'hikashop');
                    
                    if($status == true)
                    {
                        $orderStatus = 'confirmed';

                        if($dbOrder->order_status == $orderStatus)
                        {
                            SNGlobal::redirect($cancelUrl);
                        }

                        $history = new stdClass();
                        $history->notified = 0;
                        $history->data = 'شماره پیگیری  : ' . (!empty($resultData['bank_au']) ? $resultData['bank_au'] : '');

                        $config =& hikashop_config();
                        if($config->get('order_confirmed_status','confirmed') == $orderStatus)
                        {
                            $history->notified = 1;
                        }

                        $email = new stdClass();
                        $email->subject = JText::sprintf('PAYMENT_NOTIFICATION_FOR_ORDER','SnHikashop',$orderStatus,$dbOrder->order_number);
                        $email->body = str_replace('<br/>',"\r\n",JText::sprintf('PAYMENT_NOTIFICATION_STATUS','SnHikashop',$orderStatus)).' '.JText::sprintf('ORDER_STATUS_CHANGED',$orderStatus)."\r\n\r\n".$orderText;
                        $this->modifyOrder($orderId,$orderStatus,$history,$email);

                        $bankAu = !empty($resultData['bank_au']) ? $resultData['bank_au'] : $au;
                        $msg = '<h5>'.JText::_('SN_PAID_TRANSACTION').'</h5>';
                        $msg = str_replace('{REF}',$bankAu,$msg);
                        $app->redirect($successUrl, $msg , $msgType='Message');
                    }
                }
            }
	    }

        $orderStatus = $this->payment_params->invalid_status;
        $email = new stdClass();
        $email->subject = JText::sprintf('NOTIFICATION_REFUSED_FOR_THE_ORDER','SnHikashop').'invalid transaction';
        $email->body = JText::sprintf("Hello,\r\n A SnHikashop notification was refused because it could not be verified by the SnHikashop server (or pay cenceled)")."\r\n\r\n".JText::sprintf('CHECK_DOCUMENTATION',HIKASHOP_HELPURL.'payment-SnHikashop-error#invalidtnx');
        $action = false;
        $this->modifyOrder($orderId,$orderStatus,null,$email);

        $app->redirect($cancelUrl, '<h5>'.JText::_('SN_UNPAID_TRANSACTION').'</h5>' , $msgType='Error');
    }

	function onPaymentConfiguration(&$element)
	{
		parent::onPaymentConfiguration($element);
	}

	function onPaymentConfigurationSave(&$element)
	{
		return true;
	}

	function getPaymentDefaultValues(&$element)
	{
		$element->payment_name = 'پرداخت آنلاین';
		$element->payment_description='پرداخت آنلاین';

		$element->payment_params->invalid_status = 'cancelled';
		$element->payment_params->pending_status = 'created';
		$element->payment_params->verified_status = 'confirmed';
	}
}