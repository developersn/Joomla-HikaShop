<?php
defined('_JEXEC') or die('Restricted access');
?>

<div class="sn_hikashop_end" id="sn_hikashop_end">
	<span id="sn_hikashop_end_message" class="sn_hikashop_end_message">
		<?php echo JText::sprintf('PLEASE_WAIT_BEFORE_REDIRECTION_TO_X',$this->payment_name).'<br/>'. JText::_('CLICK_ON_BUTTON_IF_NOT_REDIRECTED');?> 
	</span>
	<span id="sn_hikashop_end_spinner" class="sn_hikashop_end_spinner">
		<img src="<?php echo HIKASHOP_IMAGES.'spinner.gif';?>" />
	</span>
	<br/>
	<form id="sn_hikashop_form" name="sn_hikashop_form" action="<?php echo $this->vars['action']; ?>" method="<?php echo $this->vars['method']; ?>">
		<?php foreach ($this->vars['fields'] as $key => $value): ?>
            <input type="hidden" name="<?php echo $key ?>" value="<?php echo $value; ?>" />
        <?php endforeach; ?>
        <div id="sn_hikashop_end_image" class="sn_hikashop_end_image">
			<input id="sn_hikashop_button" type="submit" class="btn btn-primary" value="<?php echo JText::_('PAY_NOW');?>" name="" alt="<?php echo JText::_('PAY_NOW');?>" onclick="document.getElementById('sn_hikashop_form').submit(); return false;"/>
		</div>
	</form>
	<script type="text/javascript">
		document.getElementById('sn_hikashop_form').submit();
	</script>
</div>